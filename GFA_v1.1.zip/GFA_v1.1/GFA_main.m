function [model,data,results] = GFA_main(model,data,n_StartPoints,parif)

%GLYCOSYLATION FLUX ANALYSIS
%
% by Sandro Hutter, CABSEL, ETH Zurich, Zurich
% Prof. Dr. Rudiyanto Gunawan, rudi.gunawan@ethz.ch
%
% Zurich, 02 August 2017
%
% DESCRIPTION: 
% This code runs an example of GFA for a given dataset of exchange fluxes.
% GFA calculates intracellular fluxes in a given glycosylation network.
% The fluxes are defined as vi(t)=aJ(t)*b(t)*vref where vref is the
% reference fluxes, b is the fold-change in the specific productivity and 
% aJ is the enzyme specific scaling factor.
%
% INPUTS:
% data.v.time        : time points of exchange flux values
% data.v.meas        : exchange flux values
% model.nReactions   : number of internal reactions
% model.nMetabolites : number of species
% model.nEnz         : number of enzymes
% model.EnzInd       : index of the last reaction catalysed by that enzyme
% model.R            : stoichiometric matrix of exchange fluxes
% model.S            : intracellular stoichiometric matrix
%
% OUTPUTS:
% results.a       : enzyme specific factor
% results.vref    : reference fluxes
% results.b       : metabolic throughput
% results.vi      : internal fluxes
% results.ve      : exchange fluxes
% results.ssr     : sum of square residuals
%% Extract inputs

vmeas   = data.v.meas;
t       = data.v.time;

%% Metabolic throughput

qmAb    = sum(data.v.meas,2);
b       = qmAb./qmAb(1);

%% Create matrix to reshape alphas in matrix form
idx = 1;
A = zeros(model.nReactions,model.nEnz);
for n = 1:length(model.EnzInd)
    for j = idx:model.EnzInd(n)
        A(j,n) = 1;
    end
    idx = model.EnzInd(n)+1;
end

%% Create start points for multistart

rs         = RandomStartPointSet('NumStartPoints',n_StartPoints);
problem    = createOptimProblem('fmincon','x0',ones(model.nReactions,1),...
             'lb',model.lb_v*ones(model.nReactions,1),...
             'ub',model.ub_v*ones(model.nReactions,1),...
             'objective',@rosenbrock);
initmatrix = list(rs,problem); % 'list' generates the matrix

%% Preallocation
vref_l  = cell(n_StartPoints,1);
a_l     = cell(n_StartPoints,1);
ssr_l   = zeros(n_StartPoints,1);


%% Solve GFA for all start points
if parif==1
    for rr = 1:n_StartPoints
        vinit = initmatrix(rr,:);
        [vref_l{rr}, a_l{rr}, ssr_l(rr)] = GFA_fixedpoint(vinit,vmeas,t,model);
    end
elseif parif==0;
    warning('Invalid input argument for parallelization')    
else
    poolobj = parpool('local',parif);
    parfor rr = 1:n_StartPoints
        vinit = initmatrix(rr,:);
        [vref_l{rr}, a_l{rr}, ssr_l(rr)] = GFA_fixedpoint(vinit,vmeas,t,model);
    end
    delete(poolobj)
end

%% Find best solution

[ssr,inx] = min(ssr_l);
vref = vref_l{inx};
a = a_l{inx};


%% Evaluate GFA output

%Scale vref so that a(1) can be set normalized as 1
vref(1:model.EnzInd(1))=vref(1:model.EnzInd(1)).*a(1,1);
for j=2:length(model.EnzInd)
    vref(model.EnzInd(j-1)+1:model.EnzInd(j)) = ...
        vref(model.EnzInd(j-1)+1:model.EnzInd(j)).*a(1,j);
end

%Normalize a
a = a./repmat(a(1,:),size(a,1),1);

%Evaluate Fluxes
vi = ones(length(t),model.nReactions);
ve = ones(length(t),model.nMetabolites);
for i=1:length(t)
    vi( i,1:model.EnzInd(1)) = ...
        vref(1:model.EnzInd(1))*a(i,1)*b(i);
    for j=2:model.nEnz
        vi( i,model.EnzInd(j-1)+1:model.EnzInd(j)) = ...
            vref(model.EnzInd(j-1)+1:model.EnzInd(j))*a(i,j)*b(i);
    end
    ve(i,:)=-inv(model.R)*model.S*vi(i,:)';
end

%% Save Results in a structure
results.a       = a;
results.vref    = vref;
results.b       = b;
results.vi      = vi;
results.ve      = ve;
results.ssr     = ssr;

results.ssr_l   = ssr_l;