%GLYCOSYLATION FLUX ANALYSIS
%
% by Sandro Hutter, CABSEL, ETH Zurich, Zurich
% Prof. Dr. Rudiyanto Gunawan, rudi.gunawan@ethz.ch
%
% Zurich, 02 August 2017
%
% DESCRIPTION:
% This code runs GFA for a given dataset of a fed-batch experiment.
% GFA calculates intracellular fluxes in a given glycosylation network.
% The fluxes are defined as vi(t)=a(t)*b(t)*vref where vref is the
% reference fluxes, b is the fold-change in the specific productivity and
% a is the enzyme specific scaling factor.
%
% INPUTS:
% model.mat                 : Model definitions
% t.mat                     : time vector
% vmeas_PrcA.mat            : secretion fluxes of process A
% vmeas_PrcB.mat            : secretion fluxes of process B
%
% REQUIRED FILES IN SAME DIRECTORY:
% GFA_main.m                : Calculates GFA results
% GFA_fixedpoint.m          : Fixed point iteration procedure
% GFA_plots                 : Generates Plots of results

%% Initialisation
clear
close all
clc


%% Load Data

load('model.mat')
load('t.mat');          data.v.time=t;
load('vmeas_PrcB.mat'); data.v.meas=vmeas_PrcB; % change A/B accordingly

%% Optimization

%Tuning parameters
n_StartPoints        = 1e2; % how many start points
parif                = 6;   % parallel workers used, 1 if not parallel

[model,data,results] = GFA_main(model,data,n_StartPoints,parif);
%% Plot results

GFA_plots(model,data,results)

%% Save Results
save('GFA.mat')


