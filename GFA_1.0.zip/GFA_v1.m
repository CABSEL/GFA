%GLYCOSYLATION FLUX ANALYSIS
%
% by Sandro Hutter, CABSEL, ETH Zurich, Zurich
% Prof. Dr. Rudiyanto Gunawan, rudi.gunawan@ethz.ch
%
% Zurich, 02 August 2017
%
% DESCRIPTION:
% This code runs GFA for a given dataset of a fed-batch experiment.
% GFA calculates intracellular fluxes in a given glycosylation network.
% The fluxes are defined as vi(t)=a(t)*b(t)*vref where vref is the
% reference fluxes, b is the fold-change in the specific productivity and
% a is the enzyme specific scaling factor.
%
% INPUTS:
% Excel File: Inputs.xlsx
%
% REQUIRED FILES IN SAME DIRECTORY:
% GFA_Data_Generation.m     : Reads in data from xcel sheet
% GFA_main.m                : Calculates GFA results
% GFA_plots                 : Generates Plots of results

%% Initialisation
clear
close all
clc

%% Load Inputs from XCEL file Inputs.xlsx

[model,data]         = GFA_Data_Generation('Inputs.xlsx');

%% Optimization

%Tuning parameters
n_StartPoints        = 1e2; % how many start points
parif                = 5;   % parallel workers used, 1 if not parallel

[model,data,results] = GFA_main(model,data,n_StartPoints,parif);
%% Plot results

GFA_plots(model,data,results)

%% Save Results
save('GFA.mat')


