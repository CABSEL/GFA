function [vend, aend, minopt] = GFA_fixedpoint(vinit,vmeas,t,model)

%GLYCOSYLATION FLUX ANALYSIS
%
% by Sandro Hutter, CABSEL, ETH Zurich, Zurich
% Prof. Dr. Rudiyanto Gunawan, rudi.gunawan@ethz.ch
%
% Zurich, 02 August 2017
%
% DESCRIPTION:
% This code is a fixed point iteration solving for vref and alpha in the
% GFA
%
% INPUTS:
% vinit: vector of initial guess for vref
% vmeas: matrix with the measured secretion fluxes (time points X fluxes)
% t:     measurement time points
% model: data structure specifying the glycosylation network
% (see readme for an example of input specifications)
%
% OUTPUTS:
% vend:  fixed point solution for vref
% aend:  fixed point solution for alpha



%% Metabolic throughput

qmAb    = sum(vmeas,2);
b       = qmAb./qmAb(1);
repb    = repmat(b,1,model.nMetabolites);
B       = diag(reshape(repb',[],1));

%% Enzyme specific factor

% create matrix to reshape alphas in matrix form
idx = 1;
A = zeros(model.nReactions,model.nEnz);
for n = 1:length(model.EnzInd)
    for j = idx:model.EnzInd(n)
        A(j,n) = 1;
    end
    idx = model.EnzInd(n)+1;
end

y = reshape(vmeas',1,[])';


%% Initialize variables

var1 = 0;
var2 = vinit(:);
var3 = 1e4;
var4 = 0;
var5 = 2e6;
var6 = 1e6;


%% FIXED POINT ITERATION

while  (var5 - var6) > 1e-10 && norm(var1-var2) + norm(var3-var4) > 1e-10 %Termination criterias
    
    % swap variables
    var1 = var2; % vref
    var3 = var4; % alpha
    var5 = var6; % fit to data
    
    %% CALCULATE ALPHAS GIVEN V REF, ALL TIME POINTS TOGETHER
    
    phi_i = repmat(var1,1,model.nEnz).*A;
    phi_e = model.S*phi_i;
    
    % repeat on block diagonal
    X =  kron(eye(length(t)),phi_e);
    
    % set up constrained linear problem for alpha given vref
    
    Alsq = -B*X; % secretion fluxes must be positive
    blsq = 0*ones(model.nMetabolites*length(t),1); % secretion fluxes must be positive
    Aeqlsq = [];
    beqlsq = [];
    lblsq = zeros(size(X,2),1); % enzyme specific factor must be postiive
    ublsq = 20*ones(size(X,2),1); % enzyme specific factor must be below 20 (value can be adjusted)
    x0lsq = []; % no initial guess required
    opts = optimoptions('lsqlin','Algorithm','interior-point');%,'Display','off');
    
    % solve constrained linear problem for alpha given vref
    
    aa=lsqlin(B*X,y,Alsq,blsq,Aeqlsq,beqlsq,lblsq,ublsq,x0lsq,opts);
    
    var4 = aa;
    
    
    %% safety exit if unfeasible
    if isempty(aa)
        vend   = NaN*ones(model.nReactions,1);
        aend   = NaN*ones(length(b),model.nEnz);
        minopt = Inf;
        return
    end
    
    
    % reshape alphas in the usual matrix form
    alpha       = ones(length(t),model.nEnz);
    inx         = 1;
    
    
    for ii=1:length(t)
        alpha(ii,:) = var4(inx:inx+model.nEnz-1);
        inx = inx+model.nEnz;
    end
    
    %% %% "obj" fun (goodness of fitting)
    ve = [];
    
    for ii=1:length(b)
        ve(ii,:) = model.S*sum(repmat(var1,1,7).*A.*repmat(alpha(ii,:),model.nReactions,1),2)*b(ii);
    end
    
    a1=norm(reshape(vmeas',[],1)-reshape(ve',[],1));
    
    %% USING THE CALCULATED ALPHAS, CALCULATE V REF
    
    % alphas are saved in the matrix alpha: row =  time point, col = enzyme.
    % we need to expand this for the enzymes, and put them on diag of a matrix
    
    Z = [];
    
    for tt = 1:length(t)
        
        % preallocation
        alpha_tilda = zeros(model.nReactions);
        
        idx = 1;
        for n = 1:length(model.EnzInd)
            for j = idx:model.EnzInd(n)
                alpha_tilda(j,j) = alpha(tt,n);
            end
            idx = model.EnzInd(n)+1;
        end
        
        Z = [Z; model.S*alpha_tilda];
        
    end
    
    
    % set up constrained linear problem for alpha given vref
    
    Alsq2 = -B*Z; %secretion fluxes must be positive
    blsq2 = zeros(model.nMetabolites*length(t),1); %secretion fluxes must be positive
    Aeqlsq2 = [];
    beqlsq2 = [];
    lblsq2 = zeros(size(B*Z,2),1); % reference fluxes must be positive
    ublsq2 = [];
    x0lsq2 = [];
    opts = optimoptions('lsqlin','Algorithm','interior-point','Display','off');
    
    [vref,minlsq2]=lsqlin(B*Z,y,Alsq2,blsq2,Aeqlsq2,beqlsq2,lblsq2,ublsq2,x0lsq2,opts); %constrain vi and vref
    
    
    %% prepare for next iteration
    
    var2 = vref;
    var6 = minlsq2;
    
    
    
    
end

if (var5 - var6) > 0 % convergence
    
    aend = alpha;
    vend = var2;
    
else                 % obj fun start increasing
    
    % reshape alphas in the usual matrix form
    aend       = ones(length(t),model.nEnz);
    inx         = 1;
    for ii=1:length(t)
        aend(ii,:) = var4(inx:inx+model.nEnz-1);
        inx = inx+model.nEnz;
    end
    
    vend = var1;
end

% calculate ssr
veend = [];

for ii=1:length(b)
    veend(ii,:) = model.S*sum(repmat(vend,1,7).*A.*repmat(aend(ii,:),model.nReactions,1),2)*b(ii);
end
minopt = norm(reshape(vmeas,[],1) - reshape(veend,[],1));

return
