function []=GFA_plots(model,data,results)
%GLYCOSYLATION FLUX ANALYSIS (Plots)
%
% by Sandro Hutter, CABSEL, ETH Zurich, Zurich
% Prof. Dr. Rudiyanto Gunawan, rudi.gunawan@ethz.ch
%
% Zurich, 02 August 2017
%
% DESCRIPTION: 
% This code generates plots with the results generated in GFA_main.
%
% INPUTS:
% data.v.time   : measurement times of secretion fluxes
% data.v.meas   : secretion flux measurements
% results.a     : enzyme specific factor      
% results.vref  : reference flux
% results.b     : metabolic throughput
% results.ve    : GFA predicted secretion fluxes
% 
% OUTPUTS:
% Figure1:  Enzyme specific factor
% Figure2:  Metabolic throughput
% Figure3:  Reference fluxes
% Figure4:  Secretion flux fitting

%% Extract Variables
t       = data.v.time;
a       = results.a;      
vref    = results.vref;
b       = results.b;
ve      = results.ve;
vmeas   = data.v.meas;


%% Alpha
figure()
plot(t,a)
xlabel('Time [d]')
ylabel('Enzyme specific factor \alpha')
legend(model.ReacEnz(model.EnzInd),'Location','NorthEastOutside')

%% Beta
figure()
plot(t,b,'b-')
xlabel('Time [d]')
ylabel('Metabolic Throughput \beta')

%% Vref
figure
hold on
bar(1:25,vref)
ylabel('vref [pg/cell/d]')

%% Secretion Fluxes
dim  = size(ve,2);
xdim = floor(sqrt(dim));
ydim = ceil(sqrt(dim));

figure()
for i=1:dim
    subplot(ydim,xdim,i)
    plot(t,vmeas(:,i),'b-')
    hold on
    plot(t,ve(:,i),'rx')
    if i==dim
        legend('Measured','GFA Results')
    else
        legend('off')
    end
    if i>(ydim-1)*xdim
        xlabel('Time [d]')
    end
    if i==1 || i==1+xdim || i==1+2*xdim || i==1+3*xdim || i==1+4*xdim
        ylabel('v_E [pg/cell/d]')
    end
    title(model.MetNames(i))
end
suptitle('Secretion Fluxes')