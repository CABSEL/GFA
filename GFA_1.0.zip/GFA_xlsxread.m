function [model,data] = GFA_xlsxread(inpFile)
%
%GLYCOSYLATION FLUX ANALYSIS (xlsx read)
%
% by Sandro Hutter, CABSEL, ETH Zurich, Zurich
% Prof. Dr. Rudiyanto Gunawan, rudi.gunawan@ethz.ch
%
% Zurich, 02 August 2017
%
%DESCRIPTION:
%Extracts data from an EXCEL file and saves them in a form that can be used
%by GFA
%
%INPUTS:
%inpFile         <- File name where data is stored
%
%OUTPUTS:
%model.Name         -> Name of Model
%model.Author       -> Author of Model
%model.nMetabolites -> Number of metabolites
%model.nReactions   -> Number of reactions
%model.N            -> Complete stoichiometry matrix
%model.S            -> Internal stoichiometry matrix
%model.R            -> Stoichiometry matrix of exchange fluxes
%model.ReacNames    -> Names of internal reactions
%model.ReacEnzymes  -> Enzyme catalysing internal reactions
%model.MetNames     -> Names of metabolites
%model.lb_v         -> Lower bound for fluxes
%model.ub_v         -> Upper bound for fluxes
%model.lb_a         -> Lower bound for fluxes
%model.ub_a         -> Upper bound for fluxes
%data.VCD.time      -> Times of VCD measurements
%data.VCd.meas      -> VCD measurements
%data.Titer.time    -> Times of titer measurements
%data.Titer.meas    -> Titer measurements
%data.Titer.tvec    -> Time vector over course of experimental data
%data.Frac.time     -> Times of fraction measurements
%data.Frac.meas     -> Fraction measurements

%% Model

[~,model.Name]          = xlsread(inpFile,'Overview','B1');
[~,model.Author]        = xlsread(inpFile,'Overview','B2');
model.nMetabolites      = xlsread(inpFile,'Overview','B6');
model.nReactions        = xlsread(inpFile,'Overview','B7');
model.lb_v              = xlsread(inpFile,'Overview','B9');
model.ub_v              = xlsread(inpFile,'Overview','B10');
model.lb_a              = xlsread(inpFile,'Overview','B11');     
model.ub_a              = xlsread(inpFile,'Overview','B12');    

[model.N,model.Ndescrpt]= xlsread(inpFile,'Stoichiometry');
model.S                 = model.N(:,model.nMetabolites+1:end);
model.R                 = model.N(:,1:model.nMetabolites);
model.ReacNames         = model.Ndescrpt(1,model.nMetabolites+2:end)';
model.ReacEnz           = model.Ndescrpt(2,model.nMetabolites+2:end)';
model.MetNames          = model.Ndescrpt(3:2+model.nMetabolites,1);

% Group Reactions catalyzed by same enzyme
i = 1;
cnt = 1;
while i<=length(model.ReacEnz)
model.EnzInd(cnt) = find(ismember(model.ReacEnz,model.ReacEnz(i)),1,'last');
i                 = model.EnzInd(cnt)+1;
cnt               = cnt+1;
end
model.nEnz        = length(model.EnzInd);
%% Data

%Experiment name
[~,data.Experiment]         = xlsread(inpFile,'Overview','B3');

%VCD
data.VCD.time           = xlsread(inpFile,'VCD','A:A');
data.VCD.meas           = xlsread(inpFile,'VCD','B:B');

%Titer 
data.Titer.time         = xlsread(inpFile,'Titer','A:A');
data.Titer.meas         = xlsread(inpFile,'Titer','B:B');

%Fractions
data.Frac.all           = xlsread(inpFile,'Fractions');
data.Frac.time          = data.Frac.all(1,:)';
data.Frac.meas          = data.Frac.all(2:end,:)';
