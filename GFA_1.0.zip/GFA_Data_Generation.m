function [model,data]=GFA_Data_Generation(inpFile)
%
%DATA_GENERATION.M
%
%by Sandro Hutter, CABSEL, ETH Zurich, Zurich
%Prof. Dr. Rudiyanto Gunawan, rudi.gunawan@ethz.ch
%
%Zurich, March 2017
%
%DESCRIPTION:
%Reads in the data from an Excel file and generates 3 matlab structures
%containing information about the inputs, model and data in a new directory
%with the same name as the input file
%
%INPUTS:
%prcID: Name of the process (identical with the Excel filename prcID.xlsx)
%
%Excel File in Data directory containing the following sheets:
%-Overview: model information, network specifics, optimizer inputs
%-Parameter: initial guess for VCD fitting
%-Stoichiometry: structure names, reaction names, stoichiometric matrix
%-VCD: viable cell density measurements
%-Titer: antibody concentratino measurements
%-Fractions: glycan fraction measurements
%
%OUTPUTS:
%inp.mat: modelling inputs
%model.mat: model/network specifications
%data.mat: data measurements, fits






%%
% % Create output directory to save results
% inp.fileID = strcat('Data/',prcID,'.xlsx');
% inp.folder = strcat(prcID,'/');
% mkdir(inp.folder);

%% Read data from Excel-File
[model,data]    = GFA_xlsxread(inpFile);

% Glycan concentrations
data.c.meas         = data.Frac.meas.*repmat(data.Titer.meas(2:end),1,model.nMetabolites)/100; %because fractions are in percent
data.c.time         = data.Frac.time;

% Fit VCD with logistic function
data.VCD.fct        = @(a,b,c,d,x) a./(exp(b.*x)+c*exp(-d.*x));
data.VCD.fit        = fit(data.VCD.time,data.VCD.meas,data.VCD.fct,fitoptions('exp2'));

% Hill type fitting for concentrations
data.c.Hillfct                  = @(a,b,n,x) a./((x/b).^(-n)+1);
data.c.Hilloptions              = fitoptions('gauss2');
data.c.Hilloptions.StartPoint   = [10 10 4];
data.c.Hilloptions.Lower        = [0 0 0];
data.c.Hilloptions.Upper        = [1e3 1e3 10];


% Concentrations
for i=1:model.nMetabolites
    if max(data.c.meas(:,i))==0 % if species is not measured, fit straight line at 0
        [data.c.fit{i},data.c.gof{i},data.c.output{i}] = fit(data.c.time,data.c.meas(:,i),'poly1');
    else
        [data.c.fit{i},data.c.gof{i},data.c.output{i}] = fit(data.c.time,data.c.meas(:,i),data.c.Hillfct,data.c.Hilloptions);
    end
    % Calculate exchange fluxes as ve=(dc/dt)/VCD
    data.v.meas(:,i) = differentiate(data.c.fit{i},data.c.time)./data.VCD.fit(data.c.time)*1000; % to get to pg/cell/day
end

data.v.time = data.c.time;

